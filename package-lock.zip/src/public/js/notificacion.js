document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("formulariofactura").addEventListener('submit', verif); 
  });
  
  function verif(evento){ 
    evento.preventDefault();
    var codigof = document.getElementById("codigof").value;
    var fechac = document.getElementById("fechac").value;
    var idc = document.getElementById("idc").value; 
    var cc = document.getElementById("cc").value;
    var tf = document.getElementById("tf").value;
    var nombrev = document.getElementById("nombrev").value;
    var fasentado = document.getElementById("fasentado").value;
    var nombrep = document.getElementById("nombrep").value;
    var articuloid = document.getElementById("articuloid").value;
    var precioc = document.getElementById("precioc").value;
    var preciov = document.getElementById("preciov").value;
    var comprapack = document.getElementById("comprapack").value;
    var cantpack = document.getElementById("cantpack").value;
    var sucid = document.getElementById("sucid").value;
    var cantmax = document.getElementById("cantmax").value;
    var cantmin = document.getElementById("cantmin").value;
    var cantmin = document.getElementById("cantmin").value;
    var states2 = ['Edinson', 'Juan', 'marlon', 'camilo','sebastian'];
    var states = ['CocaCola', 'Arroz', 'Aceite', 'Harina', 'Azucar','Manzana',
    'Cafe', 'Spaguetti', 'Panela', 'Atun', 'Pollo', 'Cerdo', 'Res', 'Macarron'
    , 'Mantequilla', 'Quesaidilla'
  ];
    console.log(idc);
    let validarNombre=states2.includes(idc);
    let validarProducto=states.includes(nombrep);
    console.log(validarNombre);
    ;
    if ( idc == ""|| articuloid == ""|| sucid == "") {
        swal ( "ups!" ,  "¡Datos Incorrectos o incompletos! verifica los campos por favor" ,  "error" )
       console.log("Error en los datos");
        return  ;
    } 
    
    
else {
    if (!validarNombre){
        swal ( "Precaucion" ,  "El Cliente adjuntado al formulario no existe, verifica su informacion por favor..." ,  "warning" );
        console.log("Nombre no existe en la base de datos");
    }

    else if (precioc>preciov){
        swal ( "¡OJO!" ,  "El Precio de Compra es mayor al precio de Venta" ,  "warning" );
        console.log("Precio de Compra erroneo ");
    }
    else if (preciov<precioc){
        swal ( "¡OJO!" ,  "El Precio de Venta es menor al precio de Compra" ,  "warning" );
        console.log("Precio de Venta erroneo ");
    }
    else{
        swal ( "Felicidades!" ,  "El producto fue agregado exitosamente" ,  "success" );
        this.submit();
    }


     
    
}
}

function verif2(){
   
  
    var idp2 = document.getElementById("idp2").value;
    var idctd2 = document.getElementById("idctd2").value;
    var idpre2 = document.getElementById("idpre2").value;
    if ( idp2 == ""|| idctd2 == ""|| idpre2 == "") {
        swal ( "ups!" ,  "¡Datos de Modificacion erroneos! verifica los campos por favor" ,  "error" )

    } else {
        swal ( "Genial" ,  "Producto Modificado" ,  "success" )
    }
}


function verif3(){
   
  
    var idnoml = document.getElementById("idnoml").value;
    var idctd3= document.getElementById("idctd3").value;
    if ( idnoml == ""|| idctd3 == "") {
        swal ( "ups!" ,  "¡Datos de Modificacion erroneos! verifica los campos del lote" ,  "error" )

    } else {
        swal ( "Genial" ,  "Lote Agregado" ,  "success" )
    }
}